#ifndef USERPROG_GDT_H
#define USERPROG_GDT_H

#include "threads/loader.h"

void gdt_init (void);

#endif /* userprog/gdt.h */
